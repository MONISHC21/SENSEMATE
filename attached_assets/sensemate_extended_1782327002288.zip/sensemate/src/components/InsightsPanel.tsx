/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { BarChart2, Eye, FileText, Mic, Hand, Clock, RefreshCw, Wifi, WifiOff } from "lucide-react";

interface UsageStats {
  objectsDetected: number;
  textsScanned: number;
  voiceInteractions: number;
  signInteractions: number;
  sessionStart: string;
}

interface FlaskStatus {
  status: "online" | "offline" | "checking";
  models?: string;
}

export default function InsightsPanel() {
  const [stats, setStats] = useState<UsageStats>({
    objectsDetected: 0,
    textsScanned: 0,
    voiceInteractions: 0,
    signInteractions: 0,
    sessionStart: new Date().toISOString(),
  });
  const [flaskStatus, setFlaskStatus] = useState<FlaskStatus>({ status: "checking" });
  const [sessionAge, setSessionAge] = useState("0m");
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchStats = async () => {
    try {
      const r = await fetch("/api/stats");
      if (r.ok) setStats(await r.json());
    } catch {
      // ignore — server might not have stats endpoint in older versions
    }
  };

  const checkFlask = async () => {
    try {
      const r = await fetch("/api/free/health", { signal: AbortSignal.timeout(3000) });
      if (r.ok) {
        setFlaskStatus({ status: "online" });
      } else {
        setFlaskStatus({ status: "offline" });
      }
    } catch {
      setFlaskStatus({ status: "offline" });
    }
  };

  const updateSessionAge = (startIso: string) => {
    const diffMs = Date.now() - new Date(startIso).getTime();
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 60) setSessionAge(`${diffMin}m`);
    else setSessionAge(`${Math.floor(diffMin / 60)}h ${diffMin % 60}m`);
  };

  useEffect(() => {
    fetchStats();
    checkFlask();
    const statsTimer = setInterval(fetchStats, 10000);
    const ageTimer = setInterval(() => {
      if (stats.sessionStart) updateSessionAge(stats.sessionStart);
    }, 30000);
    return () => {
      clearInterval(statsTimer);
      clearInterval(ageTimer);
    };
  }, []);

  useEffect(() => {
    if (stats.sessionStart) updateSessionAge(stats.sessionStart);
  }, [stats.sessionStart]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await Promise.all([fetchStats(), checkFlask()]);
    setTimeout(() => setIsRefreshing(false), 600);
  };

  const cards = [
    {
      label: "Objects Detected",
      value: stats.objectsDetected,
      icon: Eye,
      color: "text-indigo-400",
      bg: "from-indigo-500/10 to-indigo-600/5 border-indigo-500/20",
    },
    {
      label: "Texts Scanned",
      value: stats.textsScanned,
      icon: FileText,
      color: "text-emerald-400",
      bg: "from-emerald-500/10 to-emerald-600/5 border-emerald-500/20",
    },
    {
      label: "Voice Sessions",
      value: stats.voiceInteractions,
      icon: Mic,
      color: "text-sky-400",
      bg: "from-sky-500/10 to-sky-600/5 border-sky-500/20",
    },
    {
      label: "Sign Translations",
      value: stats.signInteractions,
      icon: Hand,
      color: "text-violet-400",
      bg: "from-violet-500/10 to-violet-600/5 border-violet-500/20",
    },
  ];

  const providerKey = typeof window !== "undefined"
    ? localStorage.getItem("custom_ai_provider") || "gemini"
    : "gemini";

  const providerLabel =
    providerKey === "free"
      ? "Free Local (YOLOv8 + EasyOCR + MediaPipe)"
      : providerKey === "ollama"
      ? "Local Ollama"
      : "Gemini Cloud API";

  return (
    <div id="insights-panel" className="flex flex-col gap-5">
      {/* Header row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart2 className="h-5 w-5 text-indigo-400" />
          <h3 className="font-sans font-semibold text-slate-200 text-sm">Session Insights</h3>
        </div>
        <button
          onClick={handleRefresh}
          aria-label="Refresh stats"
          className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-500 hover:text-slate-300 transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <div
              key={c.label}
              className={`p-4 bg-gradient-to-br ${c.bg} border rounded-2xl flex flex-col gap-2`}
            >
              <Icon className={`h-4 w-4 ${c.color}`} />
              <span className="font-mono font-bold text-2xl text-slate-100">{c.value}</span>
              <span className="font-sans text-[11px] text-slate-400 leading-snug">{c.label}</span>
            </div>
          );
        })}
      </div>

      {/* Session meta row */}
      <div className="flex flex-wrap gap-3 items-center">
        {/* Session duration */}
        <div className="flex items-center gap-2 px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-400">
          <Clock className="h-3.5 w-3.5 text-slate-500" />
          <span>Session active: <strong className="text-slate-300">{sessionAge}</strong></span>
        </div>

        {/* AI engine */}
        <div className="flex items-center gap-2 px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-400">
          <span className="h-2 w-2 rounded-full bg-indigo-400 inline-block" />
          <span>Engine: <strong className="text-slate-300">{providerLabel}</strong></span>
        </div>

        {/* Flask status */}
        <div
          className={`flex items-center gap-2 px-3 py-2 border rounded-xl text-xs ${
            flaskStatus.status === "online"
              ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
              : flaskStatus.status === "checking"
              ? "bg-slate-900 border-slate-800 text-slate-400"
              : "bg-rose-500/10 border-rose-500/20 text-rose-300"
          }`}
        >
          {flaskStatus.status === "online" ? (
            <Wifi className="h-3.5 w-3.5" />
          ) : (
            <WifiOff className="h-3.5 w-3.5" />
          )}
          <span>
            Free backend:{" "}
            <strong>
              {flaskStatus.status === "checking"
                ? "checking…"
                : flaskStatus.status === "online"
                ? "Online"
                : "Offline"}
            </strong>
          </span>
          {flaskStatus.status === "offline" && (
            <span className="ml-1 text-rose-400/70">
              (run <code className="font-mono bg-rose-900/20 px-1 rounded">python flask_backend/app.py</code>)
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
