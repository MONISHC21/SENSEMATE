"""
SenseMate — Free Local Python Flask Backend
Handles: EasyOCR, MediaPipe Gesture, YOLOv8 Nano Object Detection
No paid API keys needed. Runs entirely on CPU.

Usage:
    pip install -r requirements.txt
    python flask_backend/app.py

Endpoints (proxied from Node server or called directly on port 5001):
    POST /api/free/ocr         — EasyOCR text extraction
    POST /api/free/detect      — YOLOv8 Nano object detection
    POST /api/free/gesture     — MediaPipe rule-based gesture
    GET  /api/free/health      — Health check
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import base64
import io
import numpy as np
import json
import logging
import time
import os

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("sensemate-flask")

app = Flask(__name__)
CORS(app, origins=["http://localhost:3000", "http://127.0.0.1:3000"])

# ─── Lazy model holders ─────────────────────────────────────────────
_ocr_reader = None
_yolo_model = None
_mp_hands = None
_mp_drawing = None

def get_ocr_reader():
    global _ocr_reader
    if _ocr_reader is None:
        log.info("Loading EasyOCR (first call only)…")
        import easyocr
        _ocr_reader = easyocr.Reader(["en"], gpu=False)
        log.info("EasyOCR ready.")
    return _ocr_reader

def get_yolo_model():
    global _yolo_model
    if _yolo_model is None:
        log.info("Loading YOLOv8 Nano (first call only)…")
        from ultralytics import YOLO
        _yolo_model = YOLO("yolov8n.pt")   # downloads ~6 MB on first run
        log.info("YOLOv8 Nano ready.")
    return _yolo_model

def get_mediapipe_hands():
    global _mp_hands, _mp_drawing
    if _mp_hands is None:
        log.info("Loading MediaPipe Hands…")
        import mediapipe as mp
        mp_hands_module = mp.solutions.hands
        _mp_hands = mp_hands_module.Hands(
            static_image_mode=True,
            max_num_hands=1,
            min_detection_confidence=0.6,
        )
        _mp_drawing = mp.solutions.drawing_utils
        log.info("MediaPipe Hands ready.")
    return _mp_hands

# ─── Image decode helper ─────────────────────────────────────────────
def decode_image(data_url_or_b64: str):
    """Accepts data-URL (data:image/jpeg;base64,…) or raw base64. Returns cv2 BGR numpy array."""
    import cv2
    if data_url_or_b64.startswith("data:"):
        header, encoded = data_url_or_b64.split(",", 1)
    else:
        encoded = data_url_or_b64
    img_bytes = base64.b64decode(encoded)
    arr = np.frombuffer(img_bytes, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode image data.")
    return img

# ─── YOLO label filter ───────────────────────────────────────────────
TARGET_LABELS = {
    "person", "chair", "bottle", "cell phone", "laptop",
    "backpack", "car", "bus", "bicycle", "book", "clock",
    "cup", "bowl", "dining table", "door",
}

def position_label(x_center: float, img_w: int, y_center: float, img_h: int) -> str:
    """Returns human-readable spatial label based on pixel centre."""
    h_thirds = img_w / 3
    v_halves = img_h / 2
    horiz = "left" if x_center < h_thirds else ("right" if x_center > 2 * h_thirds else "center")
    vert  = "near" if y_center > v_halves else "far"
    return f"{vert} {horiz}"

# ─── MediaPipe rule-based gesture classifier ────────────────────────
def classify_gesture(landmarks) -> str:
    """
    Rule-based gesture from MediaPipe 21-point hand landmarks.
    Landmark indices: 0=wrist, 4=thumb_tip, 8=index_tip,
    12=middle_tip, 16=ring_tip, 20=pinky_tip
    """
    lms = landmarks.landmark  # MediaPipe repeated-field, supports indexing

    def y(i): return lms[i].y   # y increases downward in normalised coords
    def x(i): return lms[i].x

    thumb_up  = y(4) < y(3)
    index_up  = y(8) < y(6)
    middle_up = y(12) < y(10)
    ring_up   = y(16) < y(14)
    pinky_up  = y(20) < y(18)

    all_up   = index_up and middle_up and ring_up and pinky_up
    all_down = not index_up and not middle_up and not ring_up and not pinky_up

    # Hello → open hand, all fingers up, thumb spread
    if all_up and abs(x(4) - x(20)) > 0.15:
        return "Hello"

    # Yes → fist (all fingers down, thumb down too)
    if all_down and not thumb_up:
        return "Yes"

    # No → only index up (pointing)
    if index_up and not middle_up and not ring_up and not pinky_up:
        return "No"

    # Help → thumb tucked inside closed fingers (all_down + thumb_up crossing)
    if all_down and thumb_up:
        return "Help"

    # Thank You → flat hand, all fingers together pointing forward
    if all_up and thumb_up:
        return "Thank You"

    return "Unknown"


GESTURE_MEANINGS = {
    "Hello":     "The user is greeting you — Hello!",
    "Help":      "The user is asking for assistance — they need Help.",
    "Thank You": "The user is expressing gratitude — Thank You.",
    "Yes":       "The user is confirming — Yes.",
    "No":        "The user is declining — No.",
    "Unknown":   "Gesture not recognized. Please try again.",
}


# ─── Routes ──────────────────────────────────────────────────────────

@app.get("/api/free/health")
def health():
    return jsonify({"status": "ok", "engine": "SenseMate-Flask-Free", "time": time.time()})


@app.post("/api/free/ocr")
def ocr():
    body = request.get_json(silent=True) or {}
    image = body.get("image")
    if not image:
        return jsonify({"error": "Missing image field."}), 400

    try:
        import cv2
        img = decode_image(image)
        reader = get_ocr_reader()

        results = reader.readtext(img, detail=1)
        if not results:
            return jsonify({"extractedText": "", "confidenceScore": 0})

        # Collect text ordered top-to-bottom
        results_sorted = sorted(results, key=lambda r: r[0][0][1])  # sort by y of top-left
        lines = [r[1] for r in results_sorted]
        avg_conf = int(sum(r[2] for r in results_sorted) / len(results_sorted) * 100)

        extracted = " ".join(lines)
        log.info(f"OCR extracted {len(lines)} text segments, confidence {avg_conf}%.")
        return jsonify({"extractedText": extracted, "confidenceScore": avg_conf})

    except Exception as e:
        log.error(f"OCR error: {e}")
        return jsonify({"error": str(e)}), 500


@app.post("/api/free/detect")
def detect():
    body = request.get_json(silent=True) or {}
    image = body.get("image")
    if not image:
        return jsonify({"error": "Missing image field."}), 400

    try:
        import cv2
        img = decode_image(image)
        img_h, img_w = img.shape[:2]

        model = get_yolo_model()
        results = model(img, imgsz=320, conf=0.40, verbose=False)[0]

        objects = []
        for box in results.boxes:
            cls_id  = int(box.cls[0])
            label   = model.names[cls_id].lower()
            if label not in TARGET_LABELS:
                continue
            conf     = int(float(box.conf[0]) * 100)
            x1, y1, x2, y2 = [float(v) for v in box.xyxy[0]]
            cx, cy   = (x1 + x2) / 2, (y1 + y2) / 2
            pos      = position_label(cx, img_w, cy, img_h)
            warning  = f"{label.capitalize()} {pos}."
            objects.append({
                "label":      label,
                "position":   pos,
                "warning":    warning,
                "confidence": conf,
            })

        log.info(f"YOLO detected {len(objects)} relevant objects.")
        return jsonify({"objects": objects})

    except Exception as e:
        log.error(f"Detection error: {e}")
        return jsonify({"error": str(e)}), 500


@app.post("/api/free/gesture")
def gesture():
    body = request.get_json(silent=True) or {}
    image = body.get("image")
    if not image:
        return jsonify({"error": "Missing image field."}), 400

    try:
        import cv2
        img = decode_image(image)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        hands = get_mediapipe_hands()
        result = hands.process(img_rgb)

        if not result.multi_hand_landmarks:
            return jsonify({
                "gesture":        "Unknown",
                "meaning":        "No hand detected. Please hold your hand clearly in front of the camera.",
                "confidenceScore": 0,
            })

        gesture_name = classify_gesture(result.multi_hand_landmarks[0])
        meaning = GESTURE_MEANINGS.get(gesture_name, "Gesture not recognized.")
        confidence = 90 if gesture_name != "Unknown" else 30

        log.info(f"Gesture classified: {gesture_name} ({confidence}%)")
        return jsonify({
            "gesture":        gesture_name,
            "meaning":        meaning,
            "confidenceScore": confidence,
        })

    except Exception as e:
        log.error(f"Gesture error: {e}")
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    port = int(os.environ.get("FLASK_PORT", 5001))
    log.info(f"SenseMate Flask backend starting on http://0.0.0.0:{port}")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
