# SENSEMATE — AI-POWERED ACCESSIBILITY COMPANION

> **"See. Hear. Communicate."**
> A modular, full-stack accessibility platform for Visually Impaired, Hearing-Impaired, and Speech-Impaired individuals.

---

## 🆓 FREE PROTOTYPE MODE (No API Key Needed)

SenseMate now supports a fully **free local backend** powered by:

| Module | Engine | Cost |
|---|---|---|
| Object Detection | **YOLOv8 Nano** (runs on CPU) | Free |
| OCR Text Reader | **EasyOCR** (English) | Free |
| Sign Language Translator | **MediaPipe Hands** (rule-based) | Free |
| Speech-to-Text | **Browser Web Speech API** | Free |
| Text-to-Speech | **Browser SpeechSynthesis API** | Free |

### Quick Start (Free Mode)

**Step 1 — Start the Python free backend:**
```bash
cd flask_backend
pip install -r requirements.txt
python app.py
# Server starts on http://localhost:5001
```

**Step 2 — Start the Node/React frontend:**
```bash
npm install
npm run dev
# App starts on http://localhost:3000
```

**Step 3 — Switch to Free Mode in the UI:**
> On the Dashboard → AI Engine Settings → click **✦ Free Local** → Save

That's it. No API key, no signup, no cost.

---

## 🛠️ ARCHITECTURE

```text
Browser (React 19)
       │
       ▼
Node.js Express Server (port 3000)
  ├── /api/vision/*    → Gemini Cloud API (optional)
  ├── /api/free/*  ──→  Python Flask Server (port 5001)
  │                        ├── YOLOv8 Nano  (Object Detection)
  │                        ├── EasyOCR      (OCR)
  │                        └── MediaPipe    (Gesture)
  ├── /api/speech/*    → Gemini TTS/STT (optional)
  └── /api/stats/*     → In-memory usage tracking
```

### Three AI Provider Modes

| Mode | Vision | Speech | Cost |
|---|---|---|---|
| **✦ Free Local** | YOLOv8 + EasyOCR + MediaPipe | Browser Web Speech | $0 |
| **Gemini Cloud** | gemini-2.5-flash (vision) | Gemini TTS neural voices | Free tier (50 req/day) |
| **Ollama Local** | llama3.2-vision | Browser Web Speech | $0 (needs Ollama installed) |

---

## 🚀 CORE MODULES

1. **Object Detection** — YOLOv8 Nano detects 80 COCO objects with spatial position (near/far left/center/right), voice alerts, 5s cooldown
2. **OCR Text Reader** — EasyOCR reads labels, signs, medicines and speaks them aloud
3. **Speech-to-Text** — Browser Web Speech API for real-time transcription
4. **Text-to-Speech** — Browser SpeechSynthesis + optional Gemini neural voices
5. **Sign Language Translator** — MediaPipe rule-based gesture recognition (Hello, Help, Thank You, Yes, No)
6. **Communication Bridge** — Side-by-side multi-modal conversation panel
7. **Session Insights** — Live dashboard: objects detected, texts scanned, voice sessions, sign translations, backend health

---

## 📦 REQUIREMENTS

### Python (free backend)
```
flask>=3.0.0
flask-cors>=4.0.0
opencv-python-headless>=4.9.0
ultralytics>=8.2.0      # YOLOv8 Nano
easyocr>=1.7.1
mediapipe>=0.10.14
numpy>=1.26.0
pillow>=10.3.0
```

### Node.js
```
Node.js v18+
npm install  (installs all package.json deps)
```

---

## 📂 PROJECT STRUCTURE

```
SenseMate/
├── server.ts                    # Express server + Flask proxy + stats API
├── flask_backend/
│   ├── app.py                   # Flask: YOLOv8 + EasyOCR + MediaPipe
│   └── requirements.txt         # Python deps (free only)
├── src/
│   ├── App.tsx                  # Main controller
│   ├── types.ts                 # Shared TypeScript types
│   ├── utils/
│   │   ├── api.ts               # Provider-aware API router (free/gemini/ollama)
│   │   └── speech.ts            # Web Speech + Gemini TTS
│   └── components/
│       ├── MainDashboard.tsx    # Navigation grid
│       ├── AiEngineSettings.tsx # 3-way provider toggle (Free / Gemini / Ollama)
│       ├── InsightsPanel.tsx    # Session stats + backend health (NEW)
│       ├── ObjectDetection.tsx  # Real-time webcam detection
│       ├── OCRReader.tsx        # Document / label scanner
│       ├── SpeechToText.tsx     # Microphone transcription
│       ├── TextToSpeech.tsx     # Voice synthesis
│       ├── GestureTranslator.tsx# Sign language translation
│       ├── CommunicationBridge.tsx
│       └── AboutPage.tsx
```

---

## 🧭 FUTURE ROADMAP

- Smart Glasses Integration (WebRTC stream forwarding)
- SOS Emergency Alerts (SMS via Twilio free tier)
- Multi-language OCR (EasyOCR supports 80+ languages)
- Currency / Face Recognition
- PWA / Offline Mode
- Android App (Capacitor wrapper)

---

## 🎓 ACADEMIC CREDITS

- **Project:** SenseMate MVP
- **Developer:** Monish Nandha Balan
- **Institution:** SRM Institute of Science and Technology
- **Department:** ECE with Data Science
- **License:** Apache-2.0
